import HeroSection from "@/components/sections/HeroSection";
import AudienceSection from "@/components/sections/AudienceSection";
import PainPointsSection from "@/components/sections/PainPointsSection";
import TransformationSection from "@/components/sections/TransformationSection";
import TestimonialsSection from "@/components/sections/TestimonialsSection";
import CTASection from "@/components/sections/CTASection";
import Footer from "@/components/sections/Footer";

const Index = () => {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <AudienceSection />
      <PainPointsSection />
      <TransformationSection />
      <TestimonialsSection />
      <CTASection />
      <Footer />
    </main>
  );
};

export default Index;
