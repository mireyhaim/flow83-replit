import { Button } from "@/components/ui/button";

const HeroSection = () => {
  return (
    <section className="min-h-screen flex items-center justify-center bg-gradient-sunset relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 w-64 h-64 bg-sage-light rounded-full blur-3xl opacity-40 animate-gentle-float" />
      <div className="absolute bottom-20 right-10 w-80 h-80 bg-terracotta-light rounded-full blur-3xl opacity-30 animate-gentle-float animation-delay-400" />
      
      <div className="container mx-auto px-6 py-20 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <span className="inline-block text-sage font-body text-sm tracking-widest uppercase mb-6 opacity-0 animate-fade-up">
            A Journey Towards You
          </span>
          
          <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl text-foreground leading-tight mb-8 opacity-0 animate-fade-up animation-delay-200">
            A Gentle Path to{" "}
            <span className="text-sage italic">Inner Clarity</span>
          </h1>
          
          <p className="font-body text-lg md:text-xl text-muted-foreground leading-relaxed mb-10 opacity-0 animate-fade-up animation-delay-400">
            This is a process of gentle discovery—a space where you can pause, breathe, 
            and reconnect with what truly matters to you. Through guided reflection and 
            compassionate inquiry, we'll walk together toward a clearer understanding 
            of who you are and where you want to go.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center opacity-0 animate-fade-up animation-delay-600">
            <Button variant="gentle" size="xl">
              Begin Your Journey
            </Button>
            <Button variant="soft" size="xl">
              Learn More
            </Button>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 opacity-0 animate-fade-in animation-delay-800">
        <div className="w-6 h-10 border-2 border-sage/40 rounded-full flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-sage/60 rounded-full animate-soft-pulse" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
