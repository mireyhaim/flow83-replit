import { Heart, Compass, Sparkles, Moon } from "lucide-react";

const AudienceSection = () => {
  const audiences = [
    {
      icon: Heart,
      title: "Seekers of Self-Understanding",
      description: "You sense there's more beneath the surface, and you're ready to explore it gently.",
    },
    {
      icon: Compass,
      title: "Those at a Crossroads",
      description: "You're facing a decision or transition and need clarity to move forward with confidence.",
    },
    {
      icon: Sparkles,
      title: "Creative Souls",
      description: "You want to reconnect with your authentic voice and unlock your creative potential.",
    },
    {
      icon: Moon,
      title: "Anyone Seeking Peace",
      description: "You're looking for a moment of stillness in a world that feels too fast.",
    },
  ];

  return (
    <section className="py-24 bg-cream">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block text-terracotta font-body text-sm tracking-widest uppercase mb-4">
            Is This For You?
          </span>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-foreground leading-tight mb-6">
            This journey is designed for{" "}
            <span className="text-sage italic">you</span>
          </h2>
          <p className="font-body text-lg text-muted-foreground leading-relaxed">
            You don't need to have everything figured out. In fact, this process is most meaningful 
            for those who are still searching, still questioning, still open to discovering 
            something new about themselves.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {audiences.map((item, index) => (
            <div
              key={index}
              className="bg-background p-8 rounded-2xl shadow-soft hover:shadow-card transition-all duration-300 group"
            >
              <div className="w-14 h-14 bg-sage-light rounded-xl flex items-center justify-center mb-6 group-hover:bg-sage transition-colors duration-300">
                <item.icon className="w-7 h-7 text-sage group-hover:text-primary-foreground transition-colors duration-300" />
              </div>
              <h3 className="font-heading text-xl text-foreground mb-3">
                {item.title}
              </h3>
              <p className="font-body text-muted-foreground leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 max-w-2xl mx-auto text-center">
          <p className="font-body text-muted-foreground italic">
            "This might not be for you if you're looking for quick fixes or external validation. 
            This is inner work—gentle, but real."
          </p>
        </div>
      </div>
    </section>
  );
};

export default AudienceSection;
