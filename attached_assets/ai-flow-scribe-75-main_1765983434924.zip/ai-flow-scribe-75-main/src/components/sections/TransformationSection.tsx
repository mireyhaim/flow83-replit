import { ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const TransformationSection = () => {
  const transformations = [
    "A deeper understanding of your values and what truly matters to you",
    "Clarity about your next steps, even if you can't see the whole path yet",
    "A renewed sense of connection—to yourself and to your life's purpose",
    "Tools for self-reflection that you can carry with you always",
    "Permission to be exactly where you are, while gently moving forward",
    "A feeling of lightness, as if a weight you didn't know you were carrying has been lifted",
  ];

  return (
    <section className="py-24 bg-cream">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <span className="inline-block text-terracotta font-body text-sm tracking-widest uppercase mb-4">
              The Transformation
            </span>
            <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-foreground leading-tight mb-6">
              What awaits you on the{" "}
              <span className="text-sage italic">other side</span>
            </h2>
            <p className="font-body text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              This isn't about becoming someone new. It's about uncovering who you've always been, 
              beneath the layers of expectation and doubt.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {transformations.map((item, index) => (
              <div
                key={index}
                className="flex items-start gap-4 p-6 bg-background rounded-2xl shadow-soft hover:shadow-card transition-all duration-300"
              >
                <div className="w-8 h-8 bg-sage-light rounded-full flex items-center justify-center flex-shrink-0">
                  <Check className="w-4 h-4 text-sage" />
                </div>
                <p className="font-body text-foreground leading-relaxed">
                  {item}
                </p>
              </div>
            ))}
          </div>
          
          <div className="bg-gradient-sage rounded-3xl p-8 md:p-12 text-center">
            <p className="font-heading text-2xl md:text-3xl text-foreground mb-6 italic">
              "I can't promise you a perfect life. But I can promise you 
              a more honest relationship with the one you have."
            </p>
            <Button variant="warm" size="xl" className="group">
              Start Your Transformation
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TransformationSection;
