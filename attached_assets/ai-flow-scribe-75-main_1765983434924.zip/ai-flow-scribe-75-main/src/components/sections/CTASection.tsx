import { Button } from "@/components/ui/button";
import { ArrowRight, Leaf } from "lucide-react";

const CTASection = () => {
  return (
    <section className="py-24 bg-gradient-sage relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-10 left-10 opacity-20">
        <Leaf className="w-20 h-20 text-sage" />
      </div>
      <div className="absolute bottom-10 right-10 opacity-20 rotate-180">
        <Leaf className="w-24 h-24 text-sage" />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <span className="inline-block text-sage font-body text-sm tracking-widest uppercase mb-6">
            Your Next Step
          </span>
          
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-foreground leading-tight mb-6">
            Ready to begin your{" "}
            <span className="text-sage italic">gentle journey</span>?
          </h2>
          
          <p className="font-body text-lg md:text-xl text-muted-foreground leading-relaxed mb-10">
            There's no pressure here. No urgency. Just an open invitation to explore 
            what's possible when you give yourself permission to pause, reflect, and reconnect.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button variant="warm" size="xl" className="group">
              Begin Your Journey
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button variant="soft" size="xl">
              Ask a Question
            </Button>
          </div>
          
          <p className="font-body text-sm text-muted-foreground">
            Have questions? Reach out anytime. This is a judgment-free space.
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
