const PainPointsSection = () => {
  return (
    <section className="py-24 bg-gradient-sage relative overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute -top-20 -right-20 w-96 h-96 border border-sage/20 rounded-full" />
      <div className="absolute -bottom-32 -left-32 w-[500px] h-[500px] border border-sage/10 rounded-full" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <span className="inline-block text-sage font-body text-sm tracking-widest uppercase mb-4">
              We Understand
            </span>
            <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-foreground leading-tight">
              You might be feeling...
            </h2>
          </div>
          
          <div className="bg-background/80 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-card">
            <div className="space-y-8">
              <p className="font-body text-lg md:text-xl text-foreground leading-relaxed">
                <span className="text-sage font-medium">Stuck.</span> Like you're going 
                through the motions but not really moving forward. Every day feels the same, 
                and deep down, you know there's something more waiting for you.
              </p>
              
              <p className="font-body text-lg md:text-xl text-foreground leading-relaxed">
                <span className="text-terracotta font-medium">Overwhelmed.</span> By the 
                noise—both external and internal. There are so many voices telling you who 
                you should be, what you should want, how you should feel. And somewhere in 
                all that noise, your own voice got lost.
              </p>
              
              <p className="font-body text-lg md:text-xl text-foreground leading-relaxed">
                <span className="text-sage font-medium">Disconnected.</span> From yourself, 
                from your purpose, maybe even from the things that used to bring you joy. 
                You catch yourself wondering: "Is this really it?"
              </p>
              
              <p className="font-body text-lg md:text-xl text-foreground leading-relaxed">
                <span className="text-terracotta font-medium">Longing.</span> For something 
                you can't quite name. A sense of meaning. A feeling of being truly seen. 
                Permission to be exactly who you are.
              </p>
            </div>
            
            <div className="mt-12 pt-8 border-t border-border">
              <p className="font-heading text-xl md:text-2xl text-foreground text-center italic">
                If any of this resonates, you're in the right place. 
                <br className="hidden md:block" />
                <span className="text-sage">You're not broken. You're awakening.</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PainPointsSection;
