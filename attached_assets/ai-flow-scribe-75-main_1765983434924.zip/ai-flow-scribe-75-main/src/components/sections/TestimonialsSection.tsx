import { Quote } from "lucide-react";

const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Maya",
      text: "I came in feeling scattered and left feeling whole. For the first time in years, I can hear my own thoughts clearly.",
      feeling: "Found clarity after years of confusion",
    },
    {
      name: "David",
      text: "This wasn't therapy, it wasn't coaching—it was something gentler. Like having a conversation with the wisest part of myself.",
      feeling: "Reconnected with inner wisdom",
    },
    {
      name: "Sarah",
      text: "I finally gave myself permission to want what I want. That might sound simple, but for me, it was revolutionary.",
      feeling: "Embraced her authentic desires",
    },
    {
      name: "Michael",
      text: "The weight I didn't know I was carrying—it's gone. I breathe easier now. I move through life with more grace.",
      feeling: "Released emotional burden",
    },
    {
      name: "Elena",
      text: "I stopped fighting myself. I stopped trying to fix what wasn't broken. I just... started listening.",
      feeling: "Found self-acceptance",
    },
    {
      name: "James",
      text: "At 52, I thought I knew myself. This process showed me there's always more to discover, and that's beautiful.",
      feeling: "Discovered new depths at 52",
    },
  ];

  return (
    <section className="py-24 bg-background relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute inset-0 bg-gradient-warm opacity-50" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <span className="inline-block text-sage font-body text-sm tracking-widest uppercase mb-4">
            Voices of Transformation
          </span>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl text-foreground leading-tight">
            What others have{" "}
            <span className="text-terracotta italic">experienced</span>
          </h2>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-card p-8 rounded-2xl shadow-soft hover:shadow-card transition-all duration-300 relative group"
            >
              <Quote className="w-8 h-8 text-sage/30 absolute top-6 right-6 group-hover:text-sage/50 transition-colors" />
              <p className="font-body text-foreground leading-relaxed mb-6 relative z-10">
                "{testimonial.text}"
              </p>
              <div className="border-t border-border pt-4">
                <p className="font-heading text-lg text-foreground">
                  {testimonial.name}
                </p>
                <p className="font-body text-sm text-muted-foreground">
                  {testimonial.feeling}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
